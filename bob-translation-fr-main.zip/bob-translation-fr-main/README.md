# bob-translation-fr
Traduction du système band of blades en français pour Foundry VTT
A venir: les packs
sur le modèle de https://github.com/WallaceMcGregor/bob-translation-es - muchas gracias!
